package Main;

import login.RoleLogin;

public class Main {
    public static void main(String[] args) {
        RoleLogin roleLogin = new RoleLogin();
        roleLogin.login();
    }
}
